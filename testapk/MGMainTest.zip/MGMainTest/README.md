# MGMainTest App

App for integration test between Speech app and MG Main app.

## Requirement

* Phone should be able to connect to speech server and update grammar server (host/port depends on setup).
* Microphone permission & external storage permission enable.
* (Optional) Tools with adb logcat (e.g. Android Studio) to see logcat.

## Installation

1. Download Speech.apk and MGMainTest.apk and install into mobile.<br/><br/>
2. If you can grant microphone permission for Speech app in phone settings, please do it, if not it will ask permission when VR engine start.<br/><br/>
3. Depends on device but I recommend to open both apps once before test.<br/><br/>
4. Restart your phone, after reboot android will send android.intent.action.BOOT_COMPLETED to start Speech app. (If you do not grant microphone yet, it will invoke here). If you have logcat console attach, it will provide following log
```
	08-23 16:44:26.366 2163-2163/com.amivoicethai.speech I/SPEECH: START ENGINE 
	08-23 16:44:32.135 2163-2356/com.amivoicethai.speech I/SPEECH: INITIALIZE : OK 
	08-23 16:44:36.095 2163-2585/com.amivoicethai.speech I/SPEECH: RECORDING... 
```
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;More log details in debug and verbose level. Speech app has logcat save at [External Storage]/log and audio log at [External Storage]/AmivoiceMobileToolkit/feedback <br/><br/>
5. At this point, when you say “ฮัลโหล MG” in Thai accent, Speech app should invoke MGMainTest app to launch and show result.

>See how to integrate with Speech app and more details on Speech App projects
