package com.amivoicethai.mgvoiceassistant;

import android.app.ActivityManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import java.util.List;

import static android.content.Intent.FLAG_ACTIVITY_NEW_TASK;
import static android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP;

/**
 * Created by kai on 6/10/17.
 */

public class MGBroadcastReceiver  extends BroadcastReceiver {
    static final String MBTK_STARTED = "MBTK_STARTED";
    static final String MBTK_RESULT_ACCEPT = "MBTK_RESULT_ACCEPT";
    static final String MBTK_RESULT_REJECT = "MBTK_RESULT_REJECT";
    static final String MBTK_RESULT_CANCEL = "MBTK_RESULT_CANCEL";
    static final String MBTK_REPORT_STATE = "MBTK_REPORT_STATE";
    static final String MBTK_AUDIO_INDICATOR = "MBTK_AUDIO_INDICATOR";

    public static final int STATE_IDLE = 0;
    public static final int STATE_ACTIVATED = 1;

    @Override
    public void onReceive(Context context, Intent intent) {
            // BOOT_COMPLETED” start Service
        //Log.d("MGBroadcastReceiver","onReceive context = " + context);
        //Log.d("MGBroadcastReceiver","onReceive intent = " + intent);
        if (intent.getAction().equals(MBTK_STARTED)) {
            /*
            Intent activityIntent = new Intent(context, MainActivity.class);
            activityIntent.addFlags (FLAG_ACTIVITY_SINGLE_TOP);
            int assign_state = intent.getIntExtra("state", STATE_IDLE);
            activityIntent.putExtra("state", assign_state);
            activityIntent.setAction(MBTK_STARTED);
            context.startActivity(activityIntent);
            */
        }else if (intent.getAction().equals(MBTK_RESULT_ACCEPT)) {
            Intent activityIntent = new Intent(context, MainActivity.class);
            activityIntent.setAction(MBTK_RESULT_ACCEPT);
            activityIntent.addFlags(FLAG_ACTIVITY_SINGLE_TOP);
            activityIntent.addFlags(FLAG_ACTIVITY_NEW_TASK);
            Bundle result_bundle = intent.getBundleExtra("result");
            activityIntent.putExtra("result", result_bundle);
            context.startActivity(activityIntent);
        }else if (intent.getAction().equals(MBTK_RESULT_REJECT)) {
            /*
            Intent activityIntent = new Intent(context, MainActivity.class);
            activityIntent.setAction(MBTK_RESULT_REJECT);
            activityIntent.addFlags (FLAG_ACTIVITY_SINGLE_TOP);
            Bundle result_bundle = intent.getBundleExtra("result");
            activityIntent.putExtra("result", result_bundle);
            context.startActivity(activityIntent);
            */
        }else if (intent.getAction().equals(MBTK_RESULT_CANCEL)) {
            /*
            Intent activityIntent = new Intent(context, MainActivity.class);
            activityIntent.setAction(MBTK_RESULT_CANCEL);
            activityIntent.addFlags (FLAG_ACTIVITY_SINGLE_TOP);
            Bundle result_bundle = intent.getBundleExtra("result");
            activityIntent.putExtra("result", result_bundle);
            context.startActivity(activityIntent);
            */
        }else if (intent.getAction().equals(MBTK_REPORT_STATE)) {
           //if(isMGMainRunning(context)) {
                Log.d("MGBroadcastReceiver", "onReceive MBTK_REPORT_STATE");
                Intent activityIntent = new Intent(context, MainActivity.class);
                activityIntent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                activityIntent.addFlags(FLAG_ACTIVITY_NEW_TASK);
                activityIntent.addFlags(FLAG_ACTIVITY_SINGLE_TOP);
                int report_state = intent.getIntExtra("state", STATE_IDLE);
                Log.d("MGBroadcastReceiver", "onReceive MBTK_REPORT_STATE state = " + report_state);
                activityIntent.putExtra("state", report_state);
                activityIntent.setAction(MBTK_REPORT_STATE);
                context.startActivity(activityIntent);
            //}
        }else if (intent.getAction().equals(MBTK_AUDIO_INDICATOR)) {
            /*
            Intent activityIntent = new Intent(context, MainActivity.class);
            activityIntent.setAction(MBTK_AUDIO_INDICATOR);
            activityIntent.addFlags(FLAG_ACTIVITY_SINGLE_TOP);
            activityIntent.addFlags(FLAG_ACTIVITY_NEW_TASK);
            int volume = intent.getIntExtra("volume", 0);
            activityIntent.putExtra("volume", volume);
            context.startActivity(activityIntent);
            */
        }
    }

    public static boolean isMGMainRunning(Context context) {
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> runningProcesses = am.getRunningAppProcesses();
        for (ActivityManager.RunningAppProcessInfo processInfo : runningProcesses) {
            if (processInfo.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
                for (String activeProcess : processInfo.pkgList) {
                    Log.d("isMGMainRunning", "package " + activeProcess);
                    if (activeProcess.equals("com.amivoicethai.mgvoiceassistant")) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
}
