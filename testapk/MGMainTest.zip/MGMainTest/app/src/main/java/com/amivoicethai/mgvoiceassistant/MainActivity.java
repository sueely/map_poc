package com.amivoicethai.mgvoiceassistant;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Parcel;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

import static com.amivoicethai.mgvoiceassistant.R.color.colorAccent;

public class MainActivity extends AppCompatActivity {

    TextView result_textview;
    TextView mbtk_status;
    Button idle_button;
    Button activate_button;
    Button pause_button;
    Button resume_button;
    Button update_button;
    String speech_package = "com.amivoicethai.speech";
    String speech_class = "com.amivoicethai.mbtk.mbtkBroadcastReceiver";
    String mgmain_package = "com.amivoicethai.hybridtest";

    public static final int STATE_IDLE = 0;
    public static final int STATE_ACTIVATED = 1;

    public int current_state = STATE_IDLE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        result_textview = (TextView) findViewById(R.id.result_textview);
        mbtk_status = (TextView) findViewById(R.id.mbtk_status);

        idle_button = (Button) findViewById(R.id.idle_button);
        activate_button = (Button) findViewById(R.id.activate_button);
        pause_button = (Button) findViewById(R.id.pause_button);
        resume_button = (Button) findViewById(R.id.resume_button);
        update_button = (Button) findViewById(R.id.update_button);

        display_state();

        if(isMBTKRunning() && mbtk_status.getText().equals("OFF")){
            Intent intent = new Intent();
            intent.setComponent(new ComponentName(speech_package, speech_class));
            intent.setAction("MBTK_GET_STATE");
            intent.putExtra("partner", "MGMain");
            sendBroadcast(intent);

            Intent intent2 = new Intent();
            intent2.setComponent(new ComponentName(mgmain_package, speech_class));
            intent2.setAction("MBTK_GET_STATE");
            intent2.putExtra("partner", "MGMain");
            sendBroadcast(intent2);
        }

        update_button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setComponent(new ComponentName(speech_package, speech_class));
                intent.setAction("MBTK_UPDATE_CONTACT_LIST");
                intent.putExtra("partner", "MGMain");

                Intent intent2 = new Intent();
                intent2.setComponent(new ComponentName(mgmain_package, speech_class));
                intent2.setAction("MBTK_UPDATE_CONTACT_LIST");
                intent2.putExtra("partner", "MGMain");

                Bundle data = new Bundle();
                ArrayList<Bundle> names = new ArrayList<Bundle>();
                Bundle name_obj;

                name_obj = new Bundle();
                name_obj.putString("name", "ไก่");
                name_obj.putString("source", "Mobile");
                names.add(name_obj);

                name_obj = new Bundle();
                name_obj.putString("name", "กฤตย์");
                name_obj.putString("source", "T-BOX");
                names.add(name_obj);

                name_obj = new Bundle();
                name_obj.putString("name", "แอน");
                name_obj.putString("source", "Mobile");
                names.add(name_obj);

                name_obj = new Bundle();
                name_obj.putString("name", "นุ่น");
                name_obj.putString("source", "T-BOX");
                names.add(name_obj);

                data.putParcelableArrayList("names", names);
                intent.putExtra("contact_list", data);

                sendBroadcast(intent);
                sendBroadcast(intent2);
            }
        });

        idle_button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setComponent(new ComponentName(speech_package, speech_class));
                intent.setAction("MBTK_SET_STATE");
                intent.putExtra("partner", "MGMain");
                intent.putExtra("state", STATE_IDLE);
                sendBroadcast(intent);

                Intent intent2 = new Intent();
                intent2.setComponent(new ComponentName(mgmain_package, speech_class));
                intent2.setAction("MBTK_SET_STATE");
                intent2.putExtra("partner", "MGMain");
                intent2.putExtra("state", STATE_IDLE);
                sendBroadcast(intent2);

                display_state(0);
            }
        });

        activate_button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setComponent(new ComponentName(speech_package, speech_class));
                intent.setAction("MBTK_SET_STATE");
                intent.putExtra("partner", "MGMain");
                intent.putExtra("state", STATE_ACTIVATED);
                sendBroadcast(intent);

                Intent intent2 = new Intent();
                intent2.setComponent(new ComponentName(mgmain_package, speech_class));
                intent2.setAction("MBTK_SET_STATE");
                intent2.putExtra("partner", "MGMain");
                intent2.putExtra("state", STATE_ACTIVATED);
                sendBroadcast(intent2);

                display_state(1);
            }
        });

        pause_button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setComponent(new ComponentName(speech_package, speech_class));
                intent.setAction("MBTK_PAUSE");
                intent.putExtra("partner", "MGMain");
                sendBroadcast(intent);

                Intent intent2 = new Intent();
                intent2.setComponent(new ComponentName(mgmain_package, speech_class));
                intent2.setAction("MBTK_PAUSE");
                intent2.putExtra("partner", "MGMain");
                sendBroadcast(intent2);

                mbtk_status.setText("PAUSE");
            }
        });

        resume_button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setComponent(new ComponentName(speech_package, speech_class));
                intent.setAction("MBTK_RESUME");
                intent.putExtra("partner", "MGMain");
                sendBroadcast(intent);

                Intent intent2 = new Intent();
                intent2.setComponent(new ComponentName(mgmain_package, speech_class));
                intent2.setAction("MBTK_RESUME");
                intent2.putExtra("partner", "MGMain");
                sendBroadcast(intent2);

                if(current_state == STATE_ACTIVATED) {
                    mbtk_status.setText("ACTIVATED");
                }else{
                    mbtk_status.setText("IDLE");
                }
            }
        });

        Intent intent = getIntent();
        if(intent != null){
            doIntent(intent);
        }
    }

    public void display_state(){
        SharedPreferences sharedPref = getPreferences(Context.MODE_PRIVATE);
        current_state = sharedPref.getInt("state", STATE_IDLE);
        Log.d("display_state", "current_state " + current_state);
        if(current_state == STATE_ACTIVATED) {
            mbtk_status.setText("ACTIVATED");
            idle_button.setTextColor(Color.DKGRAY);
            activate_button.setTextColor(Color.parseColor("#FF4081"));
        }else{
            mbtk_status.setText("IDLE");
            activate_button.setTextColor(Color.DKGRAY);
            idle_button.setTextColor(Color.parseColor("#FF4081"));
        }
    }

    public void display_state(int state){
        SharedPreferences sharedPref = getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putInt("state", state);
        editor.apply();
        current_state = state;
        display_state();
    }

    public void startMBTKManual(){
        Intent intent = new Intent();
        intent.setComponent(new ComponentName(speech_package, speech_class));
        intent.putExtra("partner", "MGMain");
        intent.setAction("MBTK_START");
        sendBroadcast(intent);

        Intent intent2 = new Intent();
        intent2.setComponent(new ComponentName(mgmain_package, speech_class));
        intent2.putExtra("partner", "MGMain");
        intent2.setAction("MBTK_START");
        sendBroadcast(intent2);
    }

    private boolean isMBTKRunning() {
        ActivityManager manager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            Log.d("isMBTKRunning", "service " + service.service.getClassName());
            if ("com.amivoicethai.mbtk.mbtkConnecter".equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    @Override
    protected void onNewIntent(Intent intent) {
        doIntent(intent);
    }

    public void doIntent(Intent intent){
        String action = intent.getAction();
        String restxt = "";
        if (action.equals("MBTK_RESULT_ACCEPT")) {
            Bundle result = intent.getBundleExtra("result");
            if (result != null) {
                String keyword = "";
                String mode  = result.getString("mode");
                Boolean wake_up_word  = result.getBoolean("wake_up_word");
                if(wake_up_word){
                    display_state(1);
                }
                Float confidence  = result.getFloat("confidence");
                String command = result.getString("command");
                if(command == null) {
                    command = "";
                }
                Bundle temp  = result.getBundle("keyword");
                if(temp != null) {
                    int i = 0;
                    for (String key : temp.keySet()) {
                        if(i != 0){
                            keyword += ", ";
                        }
                        if(key.equals("names")){
                            keyword += key + " = [";
                            ArrayList<Bundle> name_arrlist = temp.getParcelableArrayList(key);
                            for (Bundle name_obj : name_arrlist) {
                                keyword += "{name : " + name_obj.getString("name") + ", source : " + name_obj.getString("source") + "},";
                            }
                            keyword += "]";
                        }else {
                            keyword += key + " = " + temp.getString(key);
                        }
                        i++;
                    }
                }
                restxt = "mode : " + mode + "\n";
                restxt += "result status : " + "ACCEPT" + "\n";
                restxt += "wake up word : " + wake_up_word.toString() + "\n";
                restxt += "confidence : " + confidence.toString() + "\n";
                restxt += "command : " + command + "\n";
                restxt += "keyword : " + keyword;

                Log.d("MGTest", "result = "+restxt);
                result_textview.setText(restxt);
            }
            display_state();
        }else if (action.equals("MBTK_RESULT_REJECT")) {
            Bundle result = intent.getBundleExtra("result");
            if (result != null) {
                String mode = result.getString("mode");
                Boolean wake_up_word = result.getBoolean("wake_up_word");
                restxt = "mode : " + mode + "\n";
                restxt += "result status : " + "REJECT" + "\n";
                restxt += "wake up word : " + wake_up_word.toString() + "\n";

                Log.d("MGTest", "result = "+restxt);
                result_textview.setText(restxt);
            }
            display_state();
        }else if (action.equals("MBTK_RESULT_CANCEL")) {
            Bundle result = intent.getBundleExtra("result");
            if (result != null) {
                String reason = result.getString("reason");
                restxt = "result status : " + "CANCEL" + "\n";
                restxt += "reason : " + reason + "\n";

                Log.d("MGTest", "result = "+restxt);
                result_textview.setText(restxt);
            }
            display_state();
        }else if (action.equals("MBTK_STARTED")) {
            mbtk_status.setText("IDLE");
            idle_button.setTextColor(Color.parseColor("#FF4081"));
            activate_button.setTextColor(Color.DKGRAY);
            result_textview.setText(restxt);
            display_state();
        }else if (action.equals("MBTK_REPORT_STATE")) {
            int report_state = intent.getIntExtra("state", 0);
            Log.d("MBTK_REPORT_STATE", "report_state = " + report_state);
            display_state(report_state);
        }else if (action.equals("MBTK_AUDIO_INDICATOR")) {
            int volume = intent.getIntExtra("volume", 0);
            //Log.d("MBTK_AUDIO_INDICATOR", "volume = " + volume);
        }
    }
}
